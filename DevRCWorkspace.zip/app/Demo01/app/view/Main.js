Ext.define('Demo01.view.Main', {
    extend: 'Ext.container.Container',
    requires: [
        'Ext.tab.Panel',
        'Ext.tab.Panel',
        'Ext.layout.container.Border',
        'Ext.form.field.Number',
        'Ext.toolbar.Toolbar',
        'Calc.*'
    ],

    xtype: 'app-main',

    layout: {
        type: 'border'
    },

    items: [{
        region: 'west',
        xtype: 'panel',
        title: 'west',
        width: 150
    }, {
        region: 'center',
        xtype: 'tabpanel',
        items: [{
            title: 'Center Tab 1',
            items: [{
                xtype: 'numberfield',
                itemId: 'txtNum1'
            }, {
                xtype: 'numberfield',
                itemId: 'txtNum2'
            }, {
                xtype: 'textfield',
                readOnly: true,
                itemId: 'txtResultado'
            }, {
                xtype: 'toolbar',
                items: [{
                    xtype: 'button',
                    itemId: 'btnSoma',
                    text: 'Soma'
                }, {
                    xtype: 'button',
                    itemId: 'btnSubtracao',
                    text: 'Subtra��o'
                }, {
                    xtype: 'button',
                    itemId: 'btnMultiplicacao',
                    text: 'Multiplica��o'
                }, {
                    xtype: 'button',
                    itemId: 'btnDivisao',
                    text: 'Divis�o'
                }]
            }]
        }]
    }],
    initComponent: function () {
        var me = this;

        me.callParent(arguments);

        me.txtNum1 = me.down('#txtNum1');
        me.txtNum2 = me.down('#txtNum2');
        me.txtResultado = me.down('#txtResultado');

        me.btnSoma = me.down('#btnSoma');
        me.btnSubtracao = me.down('#btnSubtracao');
        me.btnMultiplicacao = me.down('#btnMultiplicacao');
        me.btnDivisao = me.down('#btnDivisao');

        me.btnSoma.on('click', function () {
            var soma = Ext.create('Calc.Soma');
            me.txtResultado.setValue(soma.calcular(me.txtNum1.getValue(), me.txtNum2.getValue()));
        });
    }
});