Ext.define('Demo01.controller.Main', {
    extend: 'Ext.app.Controller'
});
